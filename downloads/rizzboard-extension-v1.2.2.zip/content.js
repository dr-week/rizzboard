(()=>{var O=[{hostPattern:/whatsapp\.com/i,name:"WhatsApp Web",bubbleSelectors:["div.message-in span.selectable-text","div.message-out span.selectable-text"],composerSelectors:['footer div[contenteditable="true"]','div[contenteditable="true"][data-tab]']},{hostPattern:/instagram\.com/i,name:"Instagram DM",bubbleSelectors:['div[role="row"] div[dir="auto"]','div[data-scope="messages_table"] div[dir="auto"]'],composerSelectors:['div[role="textbox"][contenteditable="true"]',"textarea[placeholder]"]},{hostPattern:/telegram\.org/i,name:"Telegram Web",bubbleSelectors:[".message .text-content",".bubble-content .message"],composerSelectors:['.input-message-input[contenteditable="true"]',"#editable-message-text"]},{hostPattern:/discord\.com/i,name:"Discord",bubbleSelectors:['div[id^="message-content-"]'],composerSelectors:['div[role="textbox"][data-slate-editor="true"]','div[role="textbox"][contenteditable="true"]']},{hostPattern:/(tinder|bumble|hinge|x|messenger)\.com/i,name:"Web Chat",bubbleSelectors:['[data-testid*="message"]','div[dir="auto"]',"p"],composerSelectors:["textarea",'div[role="textbox"][contenteditable="true"]']}];function E(o=location.hostname){return O.find(e=>e.hostPattern.test(o))??{hostPattern:/.*/,name:"Web Chat",bubbleSelectors:['div[dir="auto"]'],composerSelectors:["textarea",'div[role="textbox"][contenteditable="true"]','input[type="text"]']}}function y(o){if(!o||!(o instanceof HTMLElement)||o.closest("#rizzboard-wingman-host"))return!1;if(o.tagName==="TEXTAREA")return!0;if(o.tagName==="INPUT"){let e=o.type?.toLowerCase()||"text";return e==="text"||e==="search"}return o.isContentEditable}function k(o){if(o&&document.contains(o)&&y(o))return o;let e=E();for(let t of e.composerSelectors){let r=document.querySelector(t);if(r&&r.offsetParent!==null)return r}return null}function L(){let o=E(),e=[],t=Math.max(window.innerWidth,720);for(let r of o.bubbleSelectors){let n=Array.from(document.querySelectorAll(r)).slice(-18);for(let i of n){if(i.closest("#rizzboard-wingman-host")||y(i))continue;let s=(i.innerText||i.textContent||"").replace(/\s+/g," ").trim();if(!s||s.length<2||s.length>360)continue;let a=i.getBoundingClientRect();a.width<20||a.height<12||e.push({text:s,x:Math.max(0,Math.round(a.left)),y:Math.max(140,Math.round(a.top)),width:Math.round(a.width),screenWidth:t})}if(e.length>0)break}return e}function z(o){let e=()=>{setTimeout(()=>{let t=window.getSelection();if(!t||t.isCollapsed||t.rangeCount===0)return;let r=t.anchorNode instanceof Element?t.anchorNode:t.anchorNode?.parentElement??null;if(r?.closest("#rizzboard-wingman-host")||y(r))return;let n=t.toString().replace(/\s+/g," ").trim();if(n.length<3||n.length>320)return;let i=t.getRangeAt(0).getBoundingClientRect();i.width>0&&i.height>0&&o(n,i)},30)};return document.addEventListener("mouseup",e,!0),()=>document.removeEventListener("mouseup",e,!0)}function S(o,e){return`You are an elite wingman who excels at playful, concise, charismatic banter.
Your task: Suggest 3 distinct next moves for a dating app conversation.
Strict rules:
1. MAX 12 words per line.
2. NO cheesy clich\xE9 compliments like "Hey cutie" or "You must be tired from running through my mind".
3. Use witty banter, slight teasing, or confident playful framing.
4. Output MUST be valid JSON array with keys: "vibe" (Smooth | Tease | Bold) and "line" (string).

Partner said: "${o}"
${e?`Context I said previously: "${e}"`:""}

Respond ONLY with the JSON array:`}function R(o){return`You are a charisma coach. Rewrite this bland text message into 3 sharper, confident, flirty versions.
Max 12 words each.
Bland text: "${o}"

Output ONLY a JSON array with objects: [{"vibe": "Smooth", "line": "..."}, {"vibe": "Tease", "line": "..."}, {"vibe": "Bold", "line": "..."}]`}var M={"com.snapchat.android":"Snapchat","org.telegram.messenger":"Telegram","org.thoughtcrime.securesms":"Signal","co.hinge.app":"Hinge","com.bumble.app":"Bumble","com.tinder":"Tinder","com.instagram.android":"Instagram","com.whatsapp":"WhatsApp","web.whatsapp.com":"WhatsApp Web","instagram.com":"Instagram DM","web.telegram.org":"Telegram Web","tinder.com":"Tinder Web","bumble.com":"Bumble Web","discord.com":"Discord","x.com":"X DM"};function $(o){if(!o)return;let e=o.replace(/^www\./i,"");if(M[e])return M[e];let t=e.split("."),r=t[t.length-1];if(!r||["android","app","messenger","com","org","io"].includes(r)){let n=t[t.length-2];return n?n.charAt(0).toUpperCase()+n.slice(1):void 0}return r.charAt(0).toUpperCase()+r.slice(1)}function A(o){let e=$(o.appPackage);switch(o.source){case"screenshot":return"\u{1F4F8} Screenshot";case"notification":return e?`\u{1F514} ${e} Msg`:"\u{1F514} Incoming Msg";case"clipboard":return"\u{1F4CB} Copied Bubble";case"accessibility":return e?`\u{1F441}\uFE0F ${e} Scan`:"\u{1F441}\uFE0F Screen Scan";case"selection":return"\u2728 Selected Text";case"dom":return e?`\u{1F310} ${e} Chat`:"\u{1F310} Web Chat";case"manual":return"\u{1F4AC} Stealth Context"}}var w=class{recentSelfCommits=new Set;recordSelfCommit(e){let t=this.normalize(e);if(t&&(this.recentSelfCommits.add(t),this.recentSelfCommits.size>25)){let r=this.recentSelfCommits.values().next().value;r&&this.recentSelfCommits.delete(r)}}isIgnored(e,t){let r=e.trim();if(!r)return!0;if(t==="manual"||t==="selection")return!1;let n=this.normalize(r);return!!(this.recentSelfCommits.has(n)||/^https?:\/\/\S+$/i.test(r)||/^\d{4,8}$/.test(r))}normalize(e){return e.toLowerCase().replace(/\s+/g," ").trim()}};function T(o){let e={rawBlocks:o.map(r=>r.text)};if(o.length===0)return e;let t=o.filter(r=>{let n=r.y<120,i=r.y>r.screenWidth*1.8;return!n&&!i});t.sort((r,n)=>r.y-n.y);for(let r=t.length-1;r>=0;r--){let n=t[r],i=n.x+n.width/2>n.screenWidth/2;if(!i&&!e.senderText?e.senderText=n.text:i&&!e.myLastText&&(e.myLastText=n.text),e.senderText&&e.myLastText)break}return e}var D=[{id:"op-1",category:"opener",vibe:"playful",triggerKeywords:["travel","hiking","nature"],template:"Are you as adventurous as your profile says, or do you also get lost in grocery stores?"},{id:"op-2",category:"opener",vibe:"smooth",triggerKeywords:["smile","eyes","cute"],template:"I was going to wait two days to message you, but patience was never my strong suit."},{id:"op-3",category:"opener",vibe:"witty",triggerKeywords:["food","coffee","cooking"],template:"Important question: what is your most controversial culinary opinion?"},{id:"bt-1",category:"banter",vibe:"playful",triggerKeywords:["trouble","sarcasm","bad"],template:"Are you always this much trouble or did I catch you on a good day?"},{id:"bt-2",category:"banter",vibe:"witty",triggerKeywords:["challenge","bet","win"],template:"Careful, high expectations are my only weakness."},{id:"bt-3",category:"banter",vibe:"bold",triggerKeywords:["rules","late","fast"],template:"I would say you are five minutes away from being my favorite person."},{id:"wp-1",category:"wordplay",vibe:"witty",triggerKeywords:["smart","books","study","work"],template:"Are you an overdue library book? Because you have fine written all over you."},{id:"wp-2",category:"wordplay",vibe:"smooth",triggerKeywords:["music","song","playlist"],template:"If our conversation was a playlist, I would have it on repeat."},{id:"cl-1",category:"closer",vibe:"bold",triggerKeywords:["drinks","date","weekend","meet","free","tonight"],template:"Drinks this Thursday. You pick the spot, I will bring the conversation."},{id:"cl-2",category:"closer",vibe:"smooth",triggerKeywords:["coffee","tea","afternoon","sunday","morning"],template:"Let us see if you are as fun in person. Coffee tomorrow?"},{id:"rf-1",category:"banter",vibe:"playful",triggerKeywords:["red flag","toxic","flaw","worst"],template:"My biggest red flag is thinking I can win every staring contest."},{id:"sn-1",category:"banter",vibe:"bold",triggerKeywords:["snap","streak","vanish","secret","disappear"],template:"Disappearing messages just mean we have to make every line count."},{id:"wy-1",category:"banter",vibe:"witty",triggerKeywords:["wyd","doing","bored","up to","plans"],template:"Plotting my next move, and you just walked right into it."},{id:"pt-1",category:"opener",vibe:"playful",triggerKeywords:["dog","puppy","cat","pet","gym","workout"],template:"Be honest: am I competing with your pet for attention, or do I stand a chance?"}];function W(o,e=3){let t=o.toLowerCase();if(!t.trim())return[];let r=D.map(n=>{let i=0;for(let s of n.triggerKeywords)t.includes(s)&&(i+=2);return{entry:n,score:i}}).filter(n=>n.score>0);return r.sort((n,i)=>i.score-n.score),r.slice(0,e).map(n=>n.entry)}function H(o){let e=new Set(["the","and","for","are","you","that","this","with","have","what","when","where","why","how","just","like","really","very","about","from","they","them","your","mine","been","were","was","will","would","could","should","going","doing","want","need","know","think","today","tonight","tomorrow","lol","haha","lmao","yeah","yep","nope","okay","hey","hii","hello"]),t=o.toLowerCase().replace(/[^a-z0-9\s]/g," ").split(/\s+/).filter(r=>r.length>=4&&!e.has(r));return t.length>0?t[t.length-1]:null}var v=class{generateOfflineSuggestions(e,t){let r=e.trim(),n=r.toLowerCase(),i=W(r,3),s={};for(let d of i)d.vibe==="smooth"&&!s.Smooth?s.Smooth=d.template:(d.vibe==="playful"||d.vibe==="witty")&&!s.Tease?s.Tease=d.template:d.vibe==="bold"&&!s.Bold&&(s.Bold=d.template);for(let d of i)!s.Smooth&&d.template!==s.Tease&&d.template!==s.Bold?s.Smooth=d.template:!s.Tease&&d.template!==s.Smooth&&d.template!==s.Bold?s.Tease=d.template:!s.Bold&&d.template!==s.Smooth&&d.template!==s.Tease&&(s.Bold=d.template);let a=H(r),b=r.includes("?")||/^(what|why|how|where|when|who|are|do|did|would|can|wanna)\b/i.test(r),h=r.length>0&&r.split(/\s+/).length<=2&&!b,c=/^(hey|hi|hello|yo|sup|heyy+|hii+|gm|good morning)\b/i.test(n),p=/\b(sorry|my bad|apologize|late|missed)\b/i.test(n),g=/\b(cute|hot|pretty|handsome|smart|funny|sweet|love your|like your)\b/i.test(n),f=/\b(koso|kashi|kitem|khuim|mhaka|borem|barem|vhoi|naka|zala|mog)\b/i.test(n),l,u,m;return f?(l="Borem asa! Tum koso asa?",u="Arey, itlem busy asa ki mhaka visarlo?",m="Choll, coffee-k vetam\u2014kedna free asa?"):c?(l="Was literally just thinking about texting you\u2014great timing.",u="Look who finally decided to grace my notifications.",m="Hey\u2014skipping the small talk, how is your week looking?"):p?(l="All good, life happens. Just glad you are here now.",u="You owe me a coffee for the suspense, then we are even.",m="Apology accepted\u2014make it up to me this weekend?"):g?(l="Careful, keep talking like that and I might actually blush.",u="Flattery will get you everywhere\u2014what else you got?",m="Say that again in person over drinks."):b&&a?(l=`Honestly, ${a} is a whole story\u2014I will tell you the good part.`,u=`Depends\u2014are you asking about ${a} out of curiosity or research?`,m=`Better ${a} story in person. Are you free Thursday?`):b?(l="Careful, the honest answer might make you like me more.",u="I plead the fifth\u2014unless you are buying the first round.",m="Better story in person. When are we hanging out?"):h?(l="A person of few words\u2014good thing I speak fluent mystery.",u="Do not hurt your thumbs typing a whole novel over there.",m="Tell me what you are actually up to right now."):a?(l=`Okay, ${a} actually sounds like my kind of vibe.`,u=`Wait, you cannot just drop "${a}" and not elaborate.`,m=`We definitely need to talk more about ${a}\u2014coffee this week?`):n.includes("haha")||n.includes("lol")||n.includes("lmao")?(l="Making you laugh this early is dangerous for both of us.",u="Glad I could entertain you\u2014my rates go up after midnight.",m="Wait until you hear my actual voice\u2014call later?"):(l="I was going to play it cool, but you made that impossible.",u="Are you always this much trouble or is today special?",m="Skip the small talk: what is your go-to spot for drinks?"),[{vibe:"Smooth",line:s.Smooth??l},{vibe:"Tease",line:s.Tease??u},{vibe:"Bold",line:s.Bold??m}]}async generateOnlineSuggestions(e,t){let r=this.generateOfflineSuggestions(e,t);if(typeof fetch!="function")return r;let n=new AbortController,i=setTimeout(()=>n.abort(),4e3);try{let s=`${S(e,t)}
Return ONLY a JSON array of 3 objects: [{"vibe":"Smooth","line":"..."},{"vibe":"Tease","line":"..."},{"vibe":"Bold","line":"..."}]`,a=await fetch("https://text.pollinations.ai/",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({messages:[{role:"system",content:"You are a concise, witty dating/chat assistant. Reply ONLY with valid JSON."},{role:"user",content:s}],model:"openai"}),signal:n.signal});if(clearTimeout(i),!a.ok)return r;let h=(await a.text()).match(/\[[\s\S]*\]/);if(!h)return r;let c=JSON.parse(h[0]);return!Array.isArray(c)||c.length<3?r:[{vibe:"Smooth",line:String(c[0]?.line||r[0].line)},{vibe:"Tease",line:String(c[1]?.line||r[1].line)},{vibe:"Bold",line:String(c[2]?.line||r[2].line)}]}catch{return clearTimeout(i),r}}getPromptForChat(e,t){return S(e,t)}getPromptForRewrite(e){return R(e)}};var x=class{engine=new v;filter=new w;lastProcessedSignature="";recordCommittedReply(e){this.filter.recordSelfCommit(e)}isIgnoredNoiseOrSelf(e,t){return this.filter.isIgnored(e,t)}ingestRawContext(e){let t=e.text.replace(/\s+/g," ").trim();if(this.filter.isIgnored(t,e.source))return null;let r=`${e.source}:${e.appPackage??""}:${this.filter.normalize(t)}`;if(e.source!=="manual"&&e.source!=="selection"&&r===this.lastProcessedSignature)return null;this.lastProcessedSignature=r;let n=e.timestamp??Date.now();return{id:`${e.source}-${n}`,source:e.source,partnerText:t,myLastText:e.myLastText?.trim()||void 0,senderName:e.senderName?.trim()||void 0,appPackage:e.appPackage,uri:e.uri,timestamp:n}}ingestScreenBlocks(e,t,r){if(!e||e.length===0)return null;let n=T(e),i=n.senderText??n.rawBlocks.find(s=>!this.filter.isIgnored(s,t));return i?{id:`${t}-${r?.timestamp??Date.now()}`,source:t,partnerText:i.trim(),myLastText:n.myLastText?.trim(),appPackage:r?.appPackage,uri:r?.uri,timestamp:r?.timestamp??Date.now()}:null}resolveSuggestions(e){let t=this.engine.generateOfflineSuggestions(e.partnerText,e.myLastText);return{context:e,suggestions:t}}};function N(o){let e=o.trim(),t=e.toLowerCase();return e?/^(hey|hi|hello|sup|yo|wyd|what'?s up)$/i.test(e)?{score:2,verdict:"Dry",feedback:"Low effort opener. High ghosting probability (~90%).",improved:"Important question: what is your most controversial food opinion?"}:t.includes("how are you")||t.includes("how was your day")?{score:4,verdict:"Safe",feedback:"Polite but sounds like an HR interview.",improved:"Tell me your day was more exciting than grocery shopping."}:t.includes("cutie")||t.includes("beautiful")||t.includes("gorgeous")?{score:5,verdict:"Safe",feedback:"Compliment is sweet, but every other match says the exact same thing.",improved:"I was going to play it cool, but you made that impossible."}:t.includes("trouble")||t.includes("bet")||t.includes("drinks")||t.includes("coffee")?{score:9,verdict:"Smooth",feedback:"High energy, playful intrigue. Ready to send.",improved:e}:{score:7,verdict:"Smooth",feedback:"Solid message. Could use 10% more cheekiness.",improved:`${e} \u2014 unless you scare easily.`}:{score:1,verdict:"Dry",feedback:"Empty canvas. Drop something bold.",improved:"Are we breaking records or rules tonight?"}}function B(o){return o?o instanceof HTMLTextAreaElement||o instanceof HTMLInputElement?o.value||"":(o.innerText||o.textContent||"").trim():""}function I(o,e,t=!1){if(!o)return!1;if(o.focus(),o instanceof HTMLTextAreaElement||o instanceof HTMLInputElement){let r=o instanceof HTMLTextAreaElement?window.HTMLTextAreaElement.prototype:window.HTMLInputElement.prototype,n=Object.getOwnPropertyDescriptor(r,"value")?.set,i=t||!o.value?e:`${o.value} ${e}`;return n?n.call(o,i):o.value=i,o.dispatchEvent(new Event("input",{bubbles:!0})),o.dispatchEvent(new Event("change",{bubbles:!0})),!0}if(o.isContentEditable){let r=window.getSelection();if(r){let i=document.createRange();i.selectNodeContents(o),t||i.collapse(!1),r.removeAllRanges(),r.addRange(i)}return document.execCommand("insertText",!1,e)||(t?o.textContent=e:o.textContent=`${o.textContent??""}${e}`,o.dispatchEvent(new InputEvent("input",{bubbles:!0,cancelable:!0,inputType:"insertText",data:e}))),!0}return!1}var P=`
  :host {
    all: initial;
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
    color: #f3f2ee;
  }

  * {
    box-sizing: border-box;
  }

  .rb-dock {
    position: fixed;
    right: 20px;
    bottom: 24px;
    z-index: 2147483646;
    display: flex;
    flex-direction: column;
    align-items: flex-end;
    gap: 10px;
  }

  .rb-trigger {
    background: #17171b;
    color: #f3f2ee;
    border: 1px solid #30303a;
    border-bottom: 3px solid #c2272d;
    border-radius: 10px;
    padding: 8px 14px;
    font-size: 13px;
    font-weight: 700;
    letter-spacing: -0.01em;
    cursor: pointer;
    box-shadow: 0 8px 24px rgba(0, 0, 0, 0.42);
    display: inline-flex;
    align-items: center;
    gap: 7px;
    transition: transform 0.14s ease, background 0.14s ease;
  }

  .rb-trigger:hover {
    background: #202026;
    transform: translateY(-1px);
  }

  .rb-dot {
    width: 8px;
    height: 8px;
    border-radius: 50%;
    background: #ff4b72;
  }

  .rb-selection-pill {
    position: fixed;
    z-index: 2147483647;
    background: #c2272d;
    color: #ffffff;
    border: none;
    border-radius: 8px;
    padding: 5px 10px;
    font-size: 12px;
    font-weight: 700;
    cursor: pointer;
    box-shadow: 0 6px 18px rgba(0, 0, 0, 0.4);
  }

  .rb-panel {
    width: 340px;
    background: #151519;
    border: 1px solid #2d2d36;
    border-radius: 14px;
    padding: 12px;
    box-shadow: 0 18px 42px rgba(0, 0, 0, 0.55);
    display: flex;
    flex-direction: column;
    gap: 10px;
  }

  .rb-head {
    display: flex;
    justify-content: space-between;
    align-items: center;
  }

  .rb-title {
    font-size: 13px;
    font-weight: 800;
    letter-spacing: -0.01em;
    display: flex;
    align-items: center;
    gap: 6px;
  }

  .rb-badge {
    font-size: 10px;
    font-weight: 700;
    padding: 2px 7px;
    border-radius: 6px;
    background: rgba(194, 39, 45, 0.22);
    color: #ff859d;
  }

  .rb-close {
    background: transparent;
    border: none;
    color: #9a9aa6;
    cursor: pointer;
    font-size: 13px;
  }

  .rb-tabs {
    display: flex;
    gap: 6px;
    background: #1d1d23;
    padding: 4px;
    border-radius: 9px;
  }

  .rb-tab {
    flex: 1;
    border: none;
    background: transparent;
    color: #9a9aa6;
    font-size: 12px;
    font-weight: 600;
    padding: 6px 8px;
    border-radius: 6px;
    cursor: pointer;
  }

  .rb-tab.active {
    background: #2b2b34;
    color: #f3f2ee;
  }

  .rb-input-row {
    display: flex;
    gap: 6px;
  }

  .rb-input {
    flex: 1;
    background: #1e1e25;
    border: 1px solid #32323c;
    border-radius: 8px;
    padding: 7px 9px;
    color: #f3f2ee;
    font-size: 12px;
    outline: none;
  }

  .rb-input:focus {
    border-color: #ff4b72;
  }

  .rb-btn {
    background: #c2272d;
    color: #ffffff;
    border: none;
    border-radius: 8px;
    padding: 7px 10px;
    font-size: 12px;
    font-weight: 700;
    cursor: pointer;
    white-space: nowrap;
  }

  .rb-btn.secondary {
    background: #26262f;
    color: #e4e4ec;
  }

  .rb-cards {
    display: flex;
    flex-direction: column;
    gap: 6px;
  }

  .rb-card {
    background: #1f1f27;
    border: 1px solid #2e2e38;
    border-radius: 9px;
    padding: 8px 10px;
    cursor: pointer;
    display: flex;
    flex-direction: column;
    gap: 4px;
    transition: background 0.12s ease, border-color 0.12s ease;
  }

  .rb-card:hover {
    background: #272732;
    border-color: #ff4b72;
  }

  .rb-vibe {
    font-size: 10px;
    font-weight: 800;
    text-transform: uppercase;
    letter-spacing: 0.04em;
  }

  .rb-vibe.smooth { color: #6ee7b7; }
  .rb-vibe.tease { color: #fbbf24; }
  .rb-vibe.bold { color: #ff859d; }

  .rb-line {
    font-size: 12.5px;
    line-height: 1.35;
    color: #f3f2ee;
  }

  .rb-foot {
    font-size: 11px;
    color: #8c8c98;
    display: flex;
    justify-content: space-between;
  }
`;var C=class{router=new x;hostEl;shadow;isOpen=!1;activeTab="reply";activeComposer=null;resolution=null;manualContext="";statusText="Click any card to insert directly into chat";selectionChip=null;selectionTimer=null;constructor(){this.hostEl=document.createElement("div"),this.hostEl.id="rizzboard-wingman-host",this.shadow=this.hostEl.attachShadow({mode:"open"}),document.documentElement.appendChild(this.hostEl),document.addEventListener("focusin",e=>{let t=e.target;y(t)&&(this.activeComposer=t)}),this.render()}setVisible(e){this.hostEl.style.display=e?"block":"none"}togglePanel(){this.isOpen=!this.isOpen,this.isOpen&&!this.resolution?this.scanChatNow():this.render()}openWithSelection(e){this.clearSelectionChip();let t=this.router.ingestRawContext({source:"selection",text:e,appPackage:location.hostname});t&&(this.manualContext=t.partnerText,this.resolution=this.router.resolveSuggestions(t),this.activeTab="reply",this.isOpen=!0,this.render())}showSelectionTrigger(e,t){this.clearSelectionChip();let r=document.createElement("button");r.className="rb-selection-pill",r.textContent="\u26A1 Rizz Reply",r.style.top=`${Math.max(8,t.top-34)}px`,r.style.left=`${Math.min(window.innerWidth-110,Math.max(8,t.left))}px`,r.addEventListener("click",n=>{n.preventDefault(),n.stopPropagation(),this.openWithSelection(e)}),this.shadow.appendChild(r),this.selectionChip=r,this.selectionTimer=window.setTimeout(()=>this.clearSelectionChip(),4500)}clearSelectionChip(){this.selectionTimer&&(clearTimeout(this.selectionTimer),this.selectionTimer=null),this.selectionChip&&(this.selectionChip.remove(),this.selectionChip=null)}scanChatNow(){let e=L(),t=this.router.ingestScreenBlocks(e,"dom",{appPackage:location.hostname});if(t)this.manualContext=t.partnerText,this.resolution=this.router.resolveSuggestions(t),this.statusText="Scanned latest incoming chat bubble";else{let r=this.router.ingestRawContext({source:"manual",text:this.manualContext||"start playful conversation",appPackage:location.hostname});r&&(this.resolution=this.router.resolveSuggestions(r)),this.statusText="Type partner message above for tailored banter"}this.render()}insertOrCopy(e,t=!1){this.router.recordCommittedReply(e);let r=k(this.activeComposer);I(r,e,t)?this.statusText="\u2713 Inserted into chat input":(navigator.clipboard?.writeText(e).catch(()=>{}),this.statusText="\u2713 Copied to clipboard (focus chat input to auto-insert)"),this.render()}render(){this.shadow.innerHTML="";let e=document.createElement("style");e.textContent=P,this.shadow.appendChild(e);let t=document.createElement("div");t.className="rb-dock",this.isOpen&&t.appendChild(this.buildPanel());let r=document.createElement("button");r.className="rb-trigger",r.innerHTML=`<span class="rb-dot"></span><span>${this.isOpen?"Close RizzBoard":"\u26A1 RizzBoard"}</span>`,r.addEventListener("click",()=>this.togglePanel()),t.appendChild(r),this.shadow.appendChild(t)}buildPanel(){let e=document.createElement("div");e.className="rb-panel";let t=document.createElement("div");t.className="rb-head";let r=this.resolution?A(this.resolution.context):"\u26A1 Wingman";t.innerHTML=`
      <div class="rb-title">
        <span>RizzBoard Web</span>
        <span class="rb-badge">${this.escape(r)}</span>
      </div>
    `;let n=document.createElement("button");n.className="rb-close",n.textContent="\u2715",n.addEventListener("click",()=>{this.isOpen=!1,this.render()}),t.appendChild(n),e.appendChild(t);let i=document.createElement("div");i.className="rb-tabs";let s=document.createElement("button");s.className=`rb-tab ${this.activeTab==="reply"?"active":""}`,s.textContent="\u26A1 Next Move",s.addEventListener("click",()=>{this.activeTab="reply",this.render()});let a=document.createElement("button");if(a.className=`rb-tab ${this.activeTab==="roast"?"active":""}`,a.textContent="\u{1F525} Roast Draft",a.addEventListener("click",()=>{this.activeTab="roast",this.render()}),i.append(s,a),e.appendChild(i),this.activeTab==="reply"){let h=document.createElement("div");h.className="rb-input-row";let c=document.createElement("input");c.className="rb-input",c.placeholder="Partner message or prompt\u2026",c.value=this.manualContext,c.addEventListener("input",()=>{this.manualContext=c.value}),c.addEventListener("keydown",l=>{l.key==="Enter"&&this.generateManual()});let p=document.createElement("button");p.className="rb-btn secondary",p.title="Scan chat bubbles on page",p.textContent="\u{1F441}\uFE0F Scan",p.addEventListener("click",()=>this.scanChatNow());let g=document.createElement("button");g.className="rb-btn",g.textContent="Go",g.addEventListener("click",()=>this.generateManual()),h.append(c,p,g),e.appendChild(h);let f=document.createElement("div");f.className="rb-cards";for(let l of this.resolution?.suggestions??[]){let u=document.createElement("div");u.className="rb-card",u.innerHTML=`
          <span class="rb-vibe ${l.vibe.toLowerCase()}">${l.vibe}</span>
          <span class="rb-line">${this.escape(l.line)}</span>
        `,u.addEventListener("click",()=>this.insertOrCopy(l.line,!1)),f.appendChild(u)}e.appendChild(f)}else{let h=k(this.activeComposer),c=B(h)||this.manualContext,p=N(c),g=document.createElement("div");g.className="rb-card",g.innerHTML=`
        <span class="rb-vibe bold">Score: ${p.score}/10 \xB7 ${p.verdict}</span>
        <span class="rb-line">"${this.escape(p.feedback)}"</span>
      `,e.appendChild(g);let f=document.createElement("div");f.className="rb-card",f.innerHTML=`
        <span class="rb-vibe smooth">1-Click Upgrade (Click to Replace)</span>
        <span class="rb-line">${this.escape(p.improved)}</span>
      `,f.addEventListener("click",()=>this.insertOrCopy(p.improved,!0)),e.appendChild(f)}let b=document.createElement("div");return b.className="rb-foot",b.innerHTML=`<span>${this.escape(this.statusText)}</span><span>Alt+R</span>`,e.appendChild(b),e}generateManual(){let e=this.router.ingestRawContext({source:"manual",text:this.manualContext||"start playful conversation",appPackage:location.hostname});e&&(this.resolution=this.router.resolveSuggestions(e),this.statusText="Generated 3 fresh vibes (<1ms)",this.render())}escape(e){return e.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;")}};function j(){if(window.__rizzboardWingmanInitialized)return;window.__rizzboardWingmanInitialized=!0;let o=new C;z((e,t)=>{o.showSelectionTrigger(e,t)}),typeof chrome<"u"&&chrome.storage?.local&&(chrome.storage.local.get(["wingmanEnabled"],e=>{e?.wingmanEnabled===!1&&o.setVisible(!1)}),chrome.storage.onChanged?.addListener(e=>{e?.wingmanEnabled&&o.setVisible(e.wingmanEnabled.newValue!==!1)})),typeof chrome<"u"&&chrome.runtime?.onMessage&&chrome.runtime.onMessage.addListener(e=>{e?.type==="RIZZ_TOGGLE_HUD"?o.togglePanel():e?.type==="RIZZ_ANALYZE_SELECTION"&&e.text&&o.openWithSelection(String(e.text))})}j();})();
